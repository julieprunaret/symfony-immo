<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* product/details_product.html.twig */
class __TwigTemplate_c1a2d3b44f438dc3e2350449bb64c86b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "product/details_product.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "product/details_product.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "product/details_product.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "mon produit";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "\t<section class=\"py-5\">
\t\t<div class=\"container px-4 px-lg-5 my-5\">
\t\t\t<div class=\"row gx-4 gx-lg-5 align-items-center\">
\t\t\t\t<div class=\"col-md-6\"><img class=\"card-img-top mb-5 mb-md-0\" src=\"https://dummyimage.com/600x700/dee2e6/6c757d.jpg\" alt=\"...\"/> </div>
\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t<div class=\"small mb-1\">SKU: BST-498</div>
\t\t\t\t\t<h1 class=\"display-5 fw-bolder\">";
        // line 12
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["bien"]) || array_key_exists("bien", $context) ? $context["bien"] : (function () { throw new RuntimeError('Variable "bien" does not exist.', 12, $this->source); })()), "title", [], "any", false, false, false, 12), "html", null, true);
        echo "</h1>
\t\t\t\t\t<div class=\"fs-5 mb-5\">
\t\t\t\t\t\t<span>56 €</span>
\t\t\t\t\t</div>
\t\t\t\t\t<p class=\"lead\">description</p>
\t\t\t\t\t<div class=\"d-flex\">
\t\t\t\t\t\t<a class=\"btn btn-outline-dark flex-shrink-0\" href=\"\">
\t\t\t\t\t\t\tRetour
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<a class=\"btn btn-outline-dark flex-shrink-0\" href=\"\">
\t\t\t\t\t\t\t<i class=\"bi-pen me-1\"></i>
\t\t\t\t\t\t\tModifier
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<a class=\"btn btn-outline-danger flex-shrink-0\" href=\"\" >
\t\t\t\t\t\t\t<i class=\"bi-trash me-1\"></i>
\t\t\t\t\t\t\tSupprimer
\t\t\t\t\t\t</a>

\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</section>
\t\t<!-- Related items section-->
\t\t<section class=\"py-5 bg-light\">
\t\t\t<div class=\"container px-4 px-lg-5 mt-5\">
\t\t\t\t<h2 class=\"fw-bolder mb-4\">Related products</h2>
\t\t\t\t<div class=\"row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center\">
\t\t\t\t\t<div class=\"col mb-5\">
\t\t\t\t\t\t<div
\t\t\t\t\t\t\tclass=\"card h-100\">
\t\t\t\t\t\t\t<!-- Product image-->
\t\t\t\t\t\t\t<img
\t\t\t\t\t\t\tclass=\"card-img-top\" src=\"https://dummyimage.com/450x300/dee2e6/6c757d.jpg\" alt=\"...\"/>
\t\t\t\t\t\t\t<!-- Product details-->
\t\t\t\t\t\t\t<div class=\"card-body p-4\">
\t\t\t\t\t\t\t\t<div
\t\t\t\t\t\t\t\t\tclass=\"text-center\">
\t\t\t\t\t\t\t\t\t<!-- Product name-->
\t\t\t\t\t\t\t\t\t<h5 class=\"fw-bolder\">Fancy Product</h5>
\t\t\t\t\t\t\t\t\t<!-- Product price-->
\t\t\t\t\t\t\t\t\t\$40.00 - \$80.00
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- Product actions-->
\t\t\t\t\t\t\t<div class=\"card-footer p-4 pt-0 border-top-0 bg-transparent\">
\t\t\t\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\t\t\t\t<a class=\"btn btn-outline-dark mt-auto\" href=\"#\">View options</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col mb-5\">
\t\t\t\t\t\t<div
\t\t\t\t\t\t\tclass=\"card h-100\">
\t\t\t\t\t\t\t<!-- Sale badge-->
\t\t\t\t\t\t\t<div class=\"badge bg-dark text-white position-absolute\" style=\"top: 0.5rem; right: 0.5rem\">Sale</div>
\t\t\t\t\t\t\t<!-- Product image-->
\t\t\t\t\t\t\t<img
\t\t\t\t\t\t\tclass=\"card-img-top\" src=\"https://dummyimage.com/450x300/dee2e6/6c757d.jpg\" alt=\"...\"/>
\t\t\t\t\t\t\t<!-- Product details-->
\t\t\t\t\t\t\t<div class=\"card-body p-4\">
\t\t\t\t\t\t\t\t<div
\t\t\t\t\t\t\t\t\tclass=\"text-center\">
\t\t\t\t\t\t\t\t\t<!-- Product name-->
\t\t\t\t\t\t\t\t\t<h5 class=\"fw-bolder\">Special Item</h5>
\t\t\t\t\t\t\t\t\t<!-- Product reviews-->
\t\t\t\t\t\t\t\t\t<div class=\"d-flex justify-content-center small text-warning mb-2\">
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<!-- Product price-->
\t\t\t\t\t\t\t\t\t<span class=\"text-muted text-decoration-line-through\">\$20.00</span>
\t\t\t\t\t\t\t\t\t\$18.00
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- Product actions-->
\t\t\t\t\t\t\t<div class=\"card-footer p-4 pt-0 border-top-0 bg-transparent\">
\t\t\t\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\t\t\t\t<a class=\"btn btn-outline-dark mt-auto\" href=\"#\">Add to cart</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col mb-5\">
\t\t\t\t\t\t<div
\t\t\t\t\t\t\tclass=\"card h-100\">
\t\t\t\t\t\t\t<!-- Sale badge-->
\t\t\t\t\t\t\t<div class=\"badge bg-dark text-white position-absolute\" style=\"top: 0.5rem; right: 0.5rem\">Sale</div>
\t\t\t\t\t\t\t<!-- Product image-->
\t\t\t\t\t\t\t<img
\t\t\t\t\t\t\tclass=\"card-img-top\" src=\"https://dummyimage.com/450x300/dee2e6/6c757d.jpg\" alt=\"...\"/>
\t\t\t\t\t\t\t<!-- Product details-->
\t\t\t\t\t\t\t<div class=\"card-body p-4\">
\t\t\t\t\t\t\t\t<div
\t\t\t\t\t\t\t\t\tclass=\"text-center\">
\t\t\t\t\t\t\t\t\t<!-- Product name-->
\t\t\t\t\t\t\t\t\t<h5 class=\"fw-bolder\">Sale Item</h5>
\t\t\t\t\t\t\t\t\t<!-- Product price-->
\t\t\t\t\t\t\t\t\t<span class=\"text-muted text-decoration-line-through\">\$50.00</span>
\t\t\t\t\t\t\t\t\t\$25.00
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- Product actions-->
\t\t\t\t\t\t\t<div class=\"card-footer p-4 pt-0 border-top-0 bg-transparent\">
\t\t\t\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\t\t\t\t<a class=\"btn btn-outline-dark mt-auto\" href=\"#\">Add to cart</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col mb-5\">
\t\t\t\t\t\t<div
\t\t\t\t\t\t\tclass=\"card h-100\">
\t\t\t\t\t\t\t<!-- Product image-->
\t\t\t\t\t\t\t<img
\t\t\t\t\t\t\tclass=\"card-img-top\" src=\"https://dummyimage.com/450x300/dee2e6/6c757d.jpg\" alt=\"...\"/>
\t\t\t\t\t\t\t<!-- Product details-->
\t\t\t\t\t\t\t<div class=\"card-body p-4\">
\t\t\t\t\t\t\t\t<div
\t\t\t\t\t\t\t\t\tclass=\"text-center\">
\t\t\t\t\t\t\t\t\t<!-- Product name-->
\t\t\t\t\t\t\t\t\t<h5 class=\"fw-bolder\">Popular Item</h5>
\t\t\t\t\t\t\t\t\t<!-- Product reviews-->
\t\t\t\t\t\t\t\t\t<div class=\"d-flex justify-content-center small text-warning mb-2\">
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<!-- Product price-->
\t\t\t\t\t\t\t\t\t\$40.00
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- Product actions-->
\t\t\t\t\t\t\t<div class=\"card-footer p-4 pt-0 border-top-0 bg-transparent\">
\t\t\t\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\t\t\t\t<a class=\"btn btn-outline-dark mt-auto\" href=\"#\">Add to cart</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</section>
\t";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "product/details_product.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 12,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}mon produit{% endblock %}

{% block body %}
\t<section class=\"py-5\">
\t\t<div class=\"container px-4 px-lg-5 my-5\">
\t\t\t<div class=\"row gx-4 gx-lg-5 align-items-center\">
\t\t\t\t<div class=\"col-md-6\"><img class=\"card-img-top mb-5 mb-md-0\" src=\"https://dummyimage.com/600x700/dee2e6/6c757d.jpg\" alt=\"...\"/> </div>
\t\t\t\t<div class=\"col-md-6\">
\t\t\t\t\t<div class=\"small mb-1\">SKU: BST-498</div>
\t\t\t\t\t<h1 class=\"display-5 fw-bolder\">{{ bien.title }}</h1>
\t\t\t\t\t<div class=\"fs-5 mb-5\">
\t\t\t\t\t\t<span>56 €</span>
\t\t\t\t\t</div>
\t\t\t\t\t<p class=\"lead\">description</p>
\t\t\t\t\t<div class=\"d-flex\">
\t\t\t\t\t\t<a class=\"btn btn-outline-dark flex-shrink-0\" href=\"\">
\t\t\t\t\t\t\tRetour
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<a class=\"btn btn-outline-dark flex-shrink-0\" href=\"\">
\t\t\t\t\t\t\t<i class=\"bi-pen me-1\"></i>
\t\t\t\t\t\t\tModifier
\t\t\t\t\t\t</a>
\t\t\t\t\t\t<a class=\"btn btn-outline-danger flex-shrink-0\" href=\"\" >
\t\t\t\t\t\t\t<i class=\"bi-trash me-1\"></i>
\t\t\t\t\t\t\tSupprimer
\t\t\t\t\t\t</a>

\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</section>
\t\t<!-- Related items section-->
\t\t<section class=\"py-5 bg-light\">
\t\t\t<div class=\"container px-4 px-lg-5 mt-5\">
\t\t\t\t<h2 class=\"fw-bolder mb-4\">Related products</h2>
\t\t\t\t<div class=\"row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center\">
\t\t\t\t\t<div class=\"col mb-5\">
\t\t\t\t\t\t<div
\t\t\t\t\t\t\tclass=\"card h-100\">
\t\t\t\t\t\t\t<!-- Product image-->
\t\t\t\t\t\t\t<img
\t\t\t\t\t\t\tclass=\"card-img-top\" src=\"https://dummyimage.com/450x300/dee2e6/6c757d.jpg\" alt=\"...\"/>
\t\t\t\t\t\t\t<!-- Product details-->
\t\t\t\t\t\t\t<div class=\"card-body p-4\">
\t\t\t\t\t\t\t\t<div
\t\t\t\t\t\t\t\t\tclass=\"text-center\">
\t\t\t\t\t\t\t\t\t<!-- Product name-->
\t\t\t\t\t\t\t\t\t<h5 class=\"fw-bolder\">Fancy Product</h5>
\t\t\t\t\t\t\t\t\t<!-- Product price-->
\t\t\t\t\t\t\t\t\t\$40.00 - \$80.00
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- Product actions-->
\t\t\t\t\t\t\t<div class=\"card-footer p-4 pt-0 border-top-0 bg-transparent\">
\t\t\t\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\t\t\t\t<a class=\"btn btn-outline-dark mt-auto\" href=\"#\">View options</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col mb-5\">
\t\t\t\t\t\t<div
\t\t\t\t\t\t\tclass=\"card h-100\">
\t\t\t\t\t\t\t<!-- Sale badge-->
\t\t\t\t\t\t\t<div class=\"badge bg-dark text-white position-absolute\" style=\"top: 0.5rem; right: 0.5rem\">Sale</div>
\t\t\t\t\t\t\t<!-- Product image-->
\t\t\t\t\t\t\t<img
\t\t\t\t\t\t\tclass=\"card-img-top\" src=\"https://dummyimage.com/450x300/dee2e6/6c757d.jpg\" alt=\"...\"/>
\t\t\t\t\t\t\t<!-- Product details-->
\t\t\t\t\t\t\t<div class=\"card-body p-4\">
\t\t\t\t\t\t\t\t<div
\t\t\t\t\t\t\t\t\tclass=\"text-center\">
\t\t\t\t\t\t\t\t\t<!-- Product name-->
\t\t\t\t\t\t\t\t\t<h5 class=\"fw-bolder\">Special Item</h5>
\t\t\t\t\t\t\t\t\t<!-- Product reviews-->
\t\t\t\t\t\t\t\t\t<div class=\"d-flex justify-content-center small text-warning mb-2\">
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<!-- Product price-->
\t\t\t\t\t\t\t\t\t<span class=\"text-muted text-decoration-line-through\">\$20.00</span>
\t\t\t\t\t\t\t\t\t\$18.00
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- Product actions-->
\t\t\t\t\t\t\t<div class=\"card-footer p-4 pt-0 border-top-0 bg-transparent\">
\t\t\t\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\t\t\t\t<a class=\"btn btn-outline-dark mt-auto\" href=\"#\">Add to cart</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col mb-5\">
\t\t\t\t\t\t<div
\t\t\t\t\t\t\tclass=\"card h-100\">
\t\t\t\t\t\t\t<!-- Sale badge-->
\t\t\t\t\t\t\t<div class=\"badge bg-dark text-white position-absolute\" style=\"top: 0.5rem; right: 0.5rem\">Sale</div>
\t\t\t\t\t\t\t<!-- Product image-->
\t\t\t\t\t\t\t<img
\t\t\t\t\t\t\tclass=\"card-img-top\" src=\"https://dummyimage.com/450x300/dee2e6/6c757d.jpg\" alt=\"...\"/>
\t\t\t\t\t\t\t<!-- Product details-->
\t\t\t\t\t\t\t<div class=\"card-body p-4\">
\t\t\t\t\t\t\t\t<div
\t\t\t\t\t\t\t\t\tclass=\"text-center\">
\t\t\t\t\t\t\t\t\t<!-- Product name-->
\t\t\t\t\t\t\t\t\t<h5 class=\"fw-bolder\">Sale Item</h5>
\t\t\t\t\t\t\t\t\t<!-- Product price-->
\t\t\t\t\t\t\t\t\t<span class=\"text-muted text-decoration-line-through\">\$50.00</span>
\t\t\t\t\t\t\t\t\t\$25.00
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- Product actions-->
\t\t\t\t\t\t\t<div class=\"card-footer p-4 pt-0 border-top-0 bg-transparent\">
\t\t\t\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\t\t\t\t<a class=\"btn btn-outline-dark mt-auto\" href=\"#\">Add to cart</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col mb-5\">
\t\t\t\t\t\t<div
\t\t\t\t\t\t\tclass=\"card h-100\">
\t\t\t\t\t\t\t<!-- Product image-->
\t\t\t\t\t\t\t<img
\t\t\t\t\t\t\tclass=\"card-img-top\" src=\"https://dummyimage.com/450x300/dee2e6/6c757d.jpg\" alt=\"...\"/>
\t\t\t\t\t\t\t<!-- Product details-->
\t\t\t\t\t\t\t<div class=\"card-body p-4\">
\t\t\t\t\t\t\t\t<div
\t\t\t\t\t\t\t\t\tclass=\"text-center\">
\t\t\t\t\t\t\t\t\t<!-- Product name-->
\t\t\t\t\t\t\t\t\t<h5 class=\"fw-bolder\">Popular Item</h5>
\t\t\t\t\t\t\t\t\t<!-- Product reviews-->
\t\t\t\t\t\t\t\t\t<div class=\"d-flex justify-content-center small text-warning mb-2\">
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t\t<div class=\"bi-star-fill\"></div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<!-- Product price-->
\t\t\t\t\t\t\t\t\t\$40.00
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<!-- Product actions-->
\t\t\t\t\t\t\t<div class=\"card-footer p-4 pt-0 border-top-0 bg-transparent\">
\t\t\t\t\t\t\t\t<div class=\"text-center\">
\t\t\t\t\t\t\t\t\t<a class=\"btn btn-outline-dark mt-auto\" href=\"#\">Add to cart</a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</section>
\t{% endblock %}
", "product/details_product.html.twig", "D:\\Documents\\programmation\\WF3\\immo-agency\\templates\\product\\details_product.html.twig");
    }
}
