<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* includes/_navbar.html.twig */
class __TwigTemplate_503478c302f0942bb362bba77da883ea extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "includes/_navbar.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "includes/_navbar.html.twig"));

        // line 1
        echo "<!-- Navigation-->
<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">
\t<div class=\"container px-4 px-lg-5\">
\t\t<a class=\"navbar-brand\" href=\"#!\">Start Bootstrap</a>
\t\t<button
\t\t\tclass=\"navbar-toggler\"
\t\t\ttype=\"button\"
\t\t\tdata-bs-toggle=\"collapse\"
\t\t\tdata-bs-target=\"#navbarSupportedContent\"
\t\t\taria-controls=\"navbarSupportedContent\"
\t\t\taria-expanded=\"false\"
\t\t\taria-label=\"Toggle navigation\">
\t\t\t<span class=\"navbar-toggler-icon\"></span>
\t\t</button>
\t\t<div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
\t\t\t<ul class=\"navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4\">
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link active\" aria-current=\"page\" href=\"";
        // line 18
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_home");
        echo "\">Home</a>
\t\t\t\t</li>
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link\" href=\"";
        // line 21
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("add_product");
        echo "\">Ajouter</a>
\t\t\t\t</li>
\t\t\t\t<li class=\"nav-item dropdown\">
\t\t\t\t\t<a
\t\t\t\t\t\tclass=\"nav-link dropdown-toggle\"
\t\t\t\t\t\tid=\"navbarDropdown\"
\t\t\t\t\t\thref=\"#\"
\t\t\t\t\t\trole=\"button\"
\t\t\t\t\t\tdata-bs-toggle=\"dropdown\"
\t\t\t\t\t\taria-expanded=\"false\">Shop</a>
\t\t\t\t\t<ul class=\"dropdown-menu\" aria-labelledby=\"navbarDropdown\">
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#!\">All Products</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li><hr class=\"dropdown-divider\"/></li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#!\">Popular Items</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#!\">New Arrivals</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t</ul>
\t\t\t\t</li>
\t\t\t</ul>
\t\t\t<form class=\"d-flex\">
\t\t\t\t<button class=\"btn btn-outline-dark\" type=\"submit\">
\t\t\t\t\t<i class=\"bi-cart-fill me-1\"></i>
\t\t\t\t\tCart
\t\t\t\t\t<span class=\"badge bg-dark text-white ms-1 rounded-pill\">0</span>
\t\t\t\t</button>
\t\t\t</form>
\t\t</div>
\t</div>
</nav>
";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    public function getTemplateName()
    {
        return "includes/_navbar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 21,  62 => 18,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!-- Navigation-->
<nav class=\"navbar navbar-expand-lg navbar-light bg-light\">
\t<div class=\"container px-4 px-lg-5\">
\t\t<a class=\"navbar-brand\" href=\"#!\">Start Bootstrap</a>
\t\t<button
\t\t\tclass=\"navbar-toggler\"
\t\t\ttype=\"button\"
\t\t\tdata-bs-toggle=\"collapse\"
\t\t\tdata-bs-target=\"#navbarSupportedContent\"
\t\t\taria-controls=\"navbarSupportedContent\"
\t\t\taria-expanded=\"false\"
\t\t\taria-label=\"Toggle navigation\">
\t\t\t<span class=\"navbar-toggler-icon\"></span>
\t\t</button>
\t\t<div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
\t\t\t<ul class=\"navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4\">
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link active\" aria-current=\"page\" href=\"{{ path('app_home') }}\">Home</a>
\t\t\t\t</li>
\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t<a class=\"nav-link\" href=\"{{ path('add_product')}}\">Ajouter</a>
\t\t\t\t</li>
\t\t\t\t<li class=\"nav-item dropdown\">
\t\t\t\t\t<a
\t\t\t\t\t\tclass=\"nav-link dropdown-toggle\"
\t\t\t\t\t\tid=\"navbarDropdown\"
\t\t\t\t\t\thref=\"#\"
\t\t\t\t\t\trole=\"button\"
\t\t\t\t\t\tdata-bs-toggle=\"dropdown\"
\t\t\t\t\t\taria-expanded=\"false\">Shop</a>
\t\t\t\t\t<ul class=\"dropdown-menu\" aria-labelledby=\"navbarDropdown\">
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#!\">All Products</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li><hr class=\"dropdown-divider\"/></li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#!\">Popular Items</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li>
\t\t\t\t\t\t\t<a class=\"dropdown-item\" href=\"#!\">New Arrivals</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t</ul>
\t\t\t\t</li>
\t\t\t</ul>
\t\t\t<form class=\"d-flex\">
\t\t\t\t<button class=\"btn btn-outline-dark\" type=\"submit\">
\t\t\t\t\t<i class=\"bi-cart-fill me-1\"></i>
\t\t\t\t\tCart
\t\t\t\t\t<span class=\"badge bg-dark text-white ms-1 rounded-pill\">0</span>
\t\t\t\t</button>
\t\t\t</form>
\t\t</div>
\t</div>
</nav>
", "includes/_navbar.html.twig", "D:\\Documents\\programmation\\WF3\\immo-agency\\templates\\includes\\_navbar.html.twig");
    }
}
